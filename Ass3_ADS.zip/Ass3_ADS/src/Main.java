import java.util.Random;

void main() {
    MyHashTable<MyTestingClass, String> table = new MyHashTable<>(13);
    /*Use 13 as bucket size, so avg. number of
    elements in each bucket would be 10000/13=769
    */
    Random random = new Random();

    for(int i = 0; i < 10000; i++){
        int id = random.nextInt(10000);
        String name = "Name"+random.nextInt(10000);

        MyTestingClass key = new MyTestingClass(id, name);
        table.put(key, "Student"+i);
    }

    System.out.println("Total size: " + table.size());
    MyTestingClass testKey = new MyTestingClass(1, "Saida");
    table.put(testKey, "Test Student");

    System.out.println("After adding test key:");
    System.out.println("Size: " + table.size());
    System.out.println("Get test key: " + table.get(testKey));
    System.out.println("Contains 'Test Student': " + table.contains("Test Student"));
    System.out.println("Key by value: " + table.getKey("Test Student"));
    System.out.println("Bucket distribution:");
    table.printBucketSizes();

    System.out.println("Removed value: " + table.remove(testKey));
    System.out.println("Size after remove: " + table.size());
    System.out.println("Get removed key: " + table.get(testKey));
    //################################BST################################
    BST<Integer, String> tree = new BST<>();

    tree.put(1, "A");
    tree.put(2, "B");
    tree.put(3, "C");
    tree.put(4, "D");
    tree.put(5, "E");
    tree.put(6, "F");
    tree.put(7, "G");

    System.out.println("#####After insert#####");
    System.out.println("Size: " + tree.size());

    System.out.println("\n#####GET TEST#####");
    System.out.println("Key 3 → " + tree.get(3)); // B
    System.out.println("Key 7 → " + tree.get(7)); // C
    System.out.println("Key 10 → " + tree.get(10)); // null

    System.out.println("\n#####IN-ORDER TRAVERSAL#####");
    for (var elem : tree) {
        System.out.println(elem.getKey() + " -> " + elem.getValue());
    }
    // expected order: 1, 3, 4, 5, 6, 7, 8
    System.out.println("\n#####DELETE LEAF (1)#####");
    tree.delete(1);

    for (var elem : tree) {
        System.out.println(elem.getKey() + " -> " + elem.getValue());
    }

    System.out.println("\n#####DELETE NODE WITH ONE CHILD (7)#####");
    tree.delete(7);

    for (var elem : tree) {
        System.out.println(elem.getKey() + " -> " + elem.getValue());
    }

    System.out.println("\n#####DELETE NODE WITH TWO CHILDREN (5)#####");
    tree.delete(5);

    for (var elem : tree) {
        System.out.println(elem.getKey() + " -> " + elem.getValue());
    }

    System.out.println("\nFinal Size: " + tree.size());
}