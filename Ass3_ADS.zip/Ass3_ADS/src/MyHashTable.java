public class MyHashTable<K, V> {
    private static class HashNode<K, V>{
        private K key;
        private V value;
        private HashNode<K, V> next;

        public HashNode(K key, V value){
            this.key = key;
            this.value = value;
        }
    }
    private HashNode<K, V>[] chainArray;
    private int M = 19; //number of buckets
    private int size; //number of elements

    public MyHashTable(){
        chainArray = new HashNode[M];
        size = 0;
    }
    public MyHashTable(int M){
        this.M = M;
        chainArray = new HashNode[M];
        size = 0;
    }

    private int hash(K key){ //hash function
        return Math.abs(key.hashCode()) % M;
    }
    public void put(K key, V value){ //insert or update
        int index = hash(key); //creating index by hash function
        HashNode<K, V> current = chainArray[index];
        while (current != null){ //check if key exists
            if(current.key.equals(key)){
                current.value = value; //update the value
                return;
            }
            current = current.next; //iterating through table
        }
        HashNode<K, V> newNode = new HashNode<>(key, value); //inserting new node using head insertion
        newNode.next = chainArray[index];
        chainArray[index] = newNode;
        size++;
    }
    public V get(K key){ //retrieve value by key
        int index = hash(key);
        HashNode<K, V> current = chainArray[index];
        while(current!=null){
            if(current.key.equals(key)){ //found key, so return value
                return current.value;
            }
            current = current.next;
        }
        return null;
    }
    public void printBucketSizes(){ //for testing distribution
        for(int i = 0; i < M; i++){
            int count = 0;
            HashNode<K, V> current = chainArray[i];
            while(current != null){
                count++; //counts in each
                current = current.next;
            }
            System.out.println("Bucket "+i+": "+count);
        }
    }
    public V remove(K key){
        int index = hash(key);
        HashNode<K, V> current = chainArray[index]; //getting current and previous nodes
        HashNode<K, V> prev = null; //to reconnect a chain
        while(current!=null){ //check if this is the node
            if(current.key.equals(key)){
                if(prev==null){ //when need to remove first node
                    chainArray[index] = current.next; //so we remove first
                } else{
                    prev.next = current.next; //removing middle or last
                }
                size--;
                return current.value;
            }
            prev = current; //chain logic
            current = current.next;
        }
        return null;
    }
    public boolean contains(V value){
        for(int i = 0; i < M; i++){
            HashNode<K, V> current = chainArray[i];
            while(current!=null){
                if(current.value.equals(value)){ // found value
                    return true;
                }
                current = current.next;
            }
        }
        return false;
    }
    public K getKey(V value){
        for(int i = 0; i < M; i++){
            HashNode<K, V> current = chainArray[i];
            while(current!=null){
                if(current.value.equals(value)){ //found value
                    return current.key; //return key
                }
                current = current.next;
            }
        }
        return null;
    }
    public int size(){
        return size;
    }
}