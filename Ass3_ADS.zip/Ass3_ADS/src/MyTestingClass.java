public class MyTestingClass {
    // these are fields for identification and better hash distribution
    private int id;
    private String name;

    public MyTestingClass(int id, String name){
        this.id = id;
        this.name = name;
    }

    @Override
    public int hashCode(){ //main function for hashcode generation
        int hash = 7; // initial seed - prime num for decreasing collisions, less for uniform distribution

        hash = 31 * hash + id; //combine with id field
        if(name!=null){
            for(int i = 0; i < name.length(); i++){ //combine with string field. Loop ensures each char affects the hash
                hash = 31 * hash + name.charAt(i); //here we add numeric value of each char (Unicode)
            }
        }
        return hash;
    }
    @Override
    public boolean equals(Object obj){
        if(this == obj){ return true; } //same reference, so objects are equal
        if(obj == null || getClass() != obj.getClass()){ return false; } //null object or another class

        MyTestingClass other = (MyTestingClass) obj;

        if(id != other.id){ return false; } //compare ids
        if(name == null){ return other.name == null; } //compare strings handling nulls
        return name.equals(other.name); //compare actual string content
    }
    @Override
    public String toString(){
        return "MyTestingClass{id="+id+", name='"+name+"'}";
    }
}