import java.util.Iterator;
import java.util.NoSuchElementException;

public class BST<K extends Comparable<K>, V> implements Iterable<BST.Entry<K, V>> { //for-each loop
    private Node root;
    private int size;
    private class Node {
        K key;
        V val;
        Node left, right;

        Node(K key, V val) {
            this.key = key;
            this.val = val;
        }
    }
    public static class Entry<K, V> {
        private K key;
        private V value;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }
        public K getKey() {
            return key;
        }
        public V getValue() {
            return value;
        }
    }

    public void put(K key, V val) { //insert or update key-value pair
        if (root == null) { //if BST had no elements - new root
            root = new Node(key, val);
            size++;
            return;
        }

        Node current = root;
        while (true) { // infinite loop until we insert
            int cmp = key.compareTo(current.key); //compare keys
            if (cmp < 0) { //go left
                if (current.left == null) { //if no left child - create it
                    current.left = new Node(key, val);
                    size++;
                    return;
                }
                current = current.left; //otherwise go deeper
            } else if (cmp > 0) { //go right
                if (current.right == null) { //if no right child - create it
                    current.right = new Node(key, val);
                    size++;
                    return;
                }
                current = current.right; //otherwise go deeper
            } else { // key already exists - update value
                current.val = val;
                return;
            }
        }
    }
    public V get(K key) { //find value by key
        Node current = root;

        while (current != null) { //traverse the tree
            int cmp = key.compareTo(current.key); //always compare current key with desired
            if (cmp < 0) { //if less, go left
                current = current.left;
            } else if (cmp > 0) { //if more, go right
                current = current.right;
            } else { //found
                return current.val;
            }
        }
        return null; //not found
    }
    public void delete(K key) {
        Node parent = null; // parent of current node
        Node current = root; //node we will search

        // Find node
        while (current != null && !current.key.equals(key)) {
            parent = current;
            if (key.compareTo(current.key) < 0) {
                current = current.left;
            } else {
                current = current.right;
            }
        }

        if (current == null) return; //if not found - nothing to delete

        // case: two children
        if (current.left != null && current.right != null) {
            Node successorParent = current; //find smallest in right tree
            Node successor = current.right;

            while (successor.left != null) {
                successorParent = successor;
                successor = successor.left; //get the smallest in right subtree
            }

            current.key = successor.key; //replace current with successor
            current.val = successor.val;

            parent = successorParent; //delete successor instead
            current = successor;
        }

        // One child or no child
        Node child = (current.left != null) ? current.left : current.right;
        if (parent == null) { //if removing root
            root = child;
        } else if (parent.left == current) { //if current is left child
            parent.left = child;
        } else {
            parent.right = child; //if current is right child
        }
        size--;
    }
    public int size() {
        return size;
    }

    @Override
    public Iterator<Entry<K, V>> iterator() { //returns iterator for for-each loop
        return new BSTIterator();
    }
    private class BSTIterator implements Iterator<Entry<K, V>> {

        private Object[] stack; //better to use stack array to simulate recursion
        private int top; //top index of stack

        public BSTIterator() {
            stack = new Object[size]; //allocate stack - size is the num of nodes
            top = 0;
            pushLeft(root); //push all left nodes from root
        }

        // Go left as far as possible
        private void pushLeft(Node node) { //push all nodes going left in-order traversal
            while (node != null) {
                stack[top++] = node;
                node = node.left;
            }
        }
        @Override
        public boolean hasNext() { //check if elements remain
            return top > 0;
        }
        @Override
        public Entry<K, V> next() { //return next element in sorted order
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            Node node = (Node) stack[--top]; //pop from stack

            if (node.right != null) { //after visiting the node - got ot right subtree
                pushLeft(node.right);
            }

            return new Entry<>(node.key, node.val); //key-value pair
        }
    }
}